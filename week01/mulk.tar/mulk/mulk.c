long mulk(long a) {
    return a * K;
}
